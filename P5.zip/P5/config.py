class Config:
    DB_USER = "root"
    DB_PASSWORD = "Bi11s723!"
    DB_HOST = "localhost"
    DB_PORT = 3307
    DB_DATABASE = "csc206cars"